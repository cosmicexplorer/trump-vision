var act, doReplacement;

act = chrome.browserAction;

doReplacement = true;

act.onClicked.addListener(function(tab) {
  var iconPath;
  iconPath = doReplacement ? 'res/trump_headshot19off.png' : 'res/trump_headshot19.png';
  act.setIcon({
    path: iconPath
  });
  doReplacement = !doReplacement;
  return console.log("set trump vision to " + doReplacement);
});

chrome.runtime.onMessage.addListener(function(req, sender, sendResponse) {
  switch (req) {
    case 'get-do-replacement':
      return sendResponse(doReplacement);
  }
});
