require=(function e(t,n,r){function s(o,u){if(!n[o]){if(!t[o]){var a=typeof require=="function"&&require;if(!u&&a)return a(o,!0);if(i)return i(o,!0);var f=new Error("Cannot find module '"+o+"'");throw f.code="MODULE_NOT_FOUND",f}var l=n[o]={exports:{}};t[o][0].call(l.exports,function(e){var n=t[o][1][e];return s(n?n:e)},l,l.exports,e,t,n,r)}return n[o].exports}var i=typeof require=="function"&&require;for(var o=0;o<r.length;o++)s(r[o]);return s})({"/common/replace-all.js":[function(require,module,exports){
var addSad, htmlColl2Arr, insertText, watchNodesAndReplaceText;

insertText = " Sad!";

addSad = function(txt) {
  var finalText;
  finalText = txt.slice(-insertText.length);
  if (finalText !== insertText) {
    return txt.replace(/((?:\.|\?|!)?)\s*$/, function(all, g1) {
      return (g1 === '' ? '.' : g1) + insertText;
    });
  } else {
    return txt;
  }
};

htmlColl2Arr = function(coll) {
  return Array.prototype.slice.call(coll, 0);
};

watchNodesAndReplaceText = function(tag) {
  var changeText, obsv, rplc;
  changeText = function(node) {
    return node.innerHTML = addSad(node.innerHTML);
  };
  rplc = function(node) {
    var ref;
    return htmlColl2Arr((ref = typeof node.querySelectorAll === "function" ? node.querySelectorAll(tag) : void 0) != null ? ref : []).forEach(changeText);
  };
  rplc(document);
  [500, 1000, 2000].forEach(function(timeout) {
    return setTimeout((function() {
      return rplc(document);
    }), timeout);
  });
  obsv = new MutationObserver(function(records) {
    return records.forEach(function(rec) {
      var node;
      node = rec.target;
      if (rec.type === 'childList') {
        htmlColl2Arr(rec.addedNodes).forEach(rplc);
      }
      return null;
    });
  });
  setTimeout((function() {
    return obsv.observe(document, {
      childList: true,
      subtree: true
    });
  }), 2000);
  return null;
};

module.exports = {
  watchNodesAndReplaceText: watchNodesAndReplaceText
};

},{}],1:[function(require,module,exports){
var Replace;

Replace = require('../common/replace-all');

chrome.runtime.sendMessage('get-do-replacement', function(doReplacement) {
  console.log("doReplacement: " + doReplacement);
  if (doReplacement) {
    Replace.watchNodesAndReplaceText('p');
  }
  return null;
});

},{"../common/replace-all":"/common/replace-all.js"}]},{},[1]);
