var Replace;

Replace = require('../common/replace-all');

chrome.runtime.sendMessage('get-do-replacement', function(doReplacement) {
  console.log("doReplacement: " + doReplacement);
  if (doReplacement) {
    Replace.watchNodesAndReplaceText('p');
  }
  return null;
});
